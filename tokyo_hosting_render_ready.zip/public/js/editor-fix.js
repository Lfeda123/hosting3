/**
 * ملف إصلاح خطأ منشئ شريط التمرير في CodeMirror
 * يعالج خطأ "jr[n.options.scrollbarStyle] is not a constructor"
 */

(function() {
    // التأكد من أن CodeMirror موجود قبل تنفيذ الإصلاح
    if (typeof CodeMirror === 'undefined') {
        console.error('CodeMirror is not defined. Cannot apply scrollbarStyle fix.');
        return;
    }

    // إصلاح خطأ constructor لـ scrollbarStyle
    if (CodeMirror && !CodeMirror.scrollbarModel) {
        CodeMirror.scrollbarModel = {};
        CodeMirror.scrollbarModel.simple = function() {};
        CodeMirror.scrollbarModel.native = function() {};
        CodeMirror.scrollbarModel.null = function() {};
    }

    // تجاوز الدالة الأصلية لمنع استخدام خاصية scrollbarStyle
    const originalFromTextArea = CodeMirror.fromTextArea;
    
    CodeMirror.fromTextArea = function(textarea, options) {
        // إزالة خيار scrollbarStyle إذا كان موجودًا
        if (options && options.scrollbarStyle) {
            console.log('Removing scrollbarStyle option to prevent constructor error');
            delete options.scrollbarStyle;
        }
        
        // استدعاء الدالة الأصلية بالخيارات المصححة
        return originalFromTextArea.call(this, textarea, options);
    };
    
    console.log('CodeMirror scrollbarStyle fix applied successfully');
})();