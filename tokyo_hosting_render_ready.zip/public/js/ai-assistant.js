// Tokyo AI Assistant Integration
class TokyoAssistant {
    constructor() {
        this.setupUI();
        this.initializeEventListeners();
    }

    setupUI() {
        const aiSection = document.createElement('div');
        aiSection.className = 'settings-section';
        aiSection.innerHTML = `
            <h3>توكيو - المساعد الذكي</h3>
            <div class="ai-assistant-container">
                <div class="ai-chat-window" id="aiChatWindow"></div>
                <div class="ai-input-container">
                    <textarea id="aiCommand" placeholder="أخبر توكيو ماذا تريد... مثلاً: 'افتح الملف config.json' أو 'قم بإنشاء ملف جديد'" class="input"></textarea>
                    <button onclick="tokyoAssistant.sendCommand()" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i>
                        إرسال
                    </button>
                </div>
            </div>
        `;

        // Add the AI section before the first settings-section
        const firstSection = document.querySelector('.settings-section');
        if (firstSection) {
            firstSection.parentNode.insertBefore(aiSection, firstSection);
        }

        // Add styles
        const style = document.createElement('style');
        style.textContent = `
            .ai-assistant-container {
                background: var(--secondary-bg);
                border-radius: 12px;
                padding: 1rem;
                margin-top: 1rem;
            }

            .ai-chat-window {
                height: 300px;
                overflow-y: auto;
                padding: 1rem;
                background: var(--primary-bg);
                border-radius: 8px;
                margin-bottom: 1rem;
            }

            .ai-message {
                margin-bottom: 1rem;
                padding: 0.8rem;
                border-radius: 8px;
                max-width: 80%;
                word-wrap: break-word;
            }

            .ai-message.user {
                background: var(--accent-color);
                margin-left: auto;
                color: white;
            }

            .ai-message.assistant {
                background: var(--tertiary-bg);
                margin-right: auto;
            }

            .ai-input-container {
                display: flex;
                gap: 1rem;
            }

            .ai-input-container textarea {
                flex: 1;
                min-height: 60px;
                resize: vertical;
            }

            .ai-message pre {
                background: rgba(0, 0, 0, 0.2);
                padding: 0.5rem;
                border-radius: 4px;
                overflow-x: auto;
                font-size: 0.9em;
                direction: ltr;
            }

            .ai-message code {
                font-family: 'Menlo', 'Monaco', 'Consolas', monospace;
            }

            .typing-indicator {
                display: flex;
                align-items: center;
                gap: 0.3rem;
                padding: 0.5rem;
                background: rgba(255, 255, 255, 0.1);
                border-radius: 12px;
                width: fit-content;
                margin-bottom: 1rem;
            }

            .typing-dot {
                width: 8px;
                height: 8px;
                background: var(--accent-color);
                border-radius: 50%;
                opacity: 0.6;
                animation: typingAnimation 1s infinite ease-in-out;
            }

            .typing-dot:nth-child(1) { animation-delay: 0s; }
            .typing-dot:nth-child(2) { animation-delay: 0.2s; }
            .typing-dot:nth-child(3) { animation-delay: 0.4s; }

            @keyframes typingAnimation {
                0%, 100% { transform: translateY(0); }
                50% { transform: translateY(-5px); }
            }
        `;
        document.head.appendChild(style);
    }

    initializeEventListeners() {
        // Add enter key support (Shift+Enter for new line)
        document.getElementById('aiCommand').addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendCommand();
            }
        });
    }

    async sendCommand() {
        const commandInput = document.getElementById('aiCommand');
        const command = commandInput.value.trim();

        if (!command) return;

        // Add user message to chat
        this.addMessage(command, 'user');
        commandInput.value = '';

        // Show typing indicator
        this.showTypingIndicator();

        try {
            const response = await fetch(`/api/ai-assistant/${serverName}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    command: command,
                    filePath: window.currentFilePath || ''
                })
            });

            const result = await response.json();
            this.hideTypingIndicator();

            if (result.success) {
                // Handle different types of responses
                if (result.action === 'view') {
                    this.addMessage('محتوى الملف:', 'assistant');
                    this.addMessage(result.content, 'assistant', 'code');
                } else if (result.action === 'edit') {
                    this.addMessage('تم تحديث الملف بنجاح ✅', 'assistant');
                    if (typeof refreshFileList === 'function') {
                        refreshFileList();
                    }
                } else if (result.action === 'create' || result.action === 'create_folder') {
                    this.addMessage('تم إنشاء ' + (result.action === 'create' ? 'الملف' : 'المجلد') + ' بنجاح ✅', 'assistant');
                    if (typeof refreshFileList === 'function') {
                        refreshFileList();
                    }
                } else if (result.action === 'delete') {
                    this.addMessage('تم حذف الملف بنجاح ✅', 'assistant');
                    if (typeof refreshFileList === 'function') {
                        refreshFileList();
                    }
                } else {
                    this.addMessage(result.message, 'assistant');
                }
            } else {
                this.addMessage('عذراً، حدث خطأ: ' + result.error, 'assistant', 'error');
            }
        } catch (error) {
            this.hideTypingIndicator();
            console.error('Error:', error);
            this.addMessage('عذراً، حدث خطأ في الاتصال', 'assistant', 'error');
        }
    }

    showTypingIndicator() {
        const chatWindow = document.getElementById('aiChatWindow');
        const typingIndicator = document.createElement('div');
        typingIndicator.className = 'typing-indicator';
        typingIndicator.id = 'typingIndicator';
        typingIndicator.innerHTML = `
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        `;
        chatWindow.appendChild(typingIndicator);
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }

    hideTypingIndicator() {
        const typingIndicator = document.getElementById('typingIndicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    addMessage(message, type, style = '') {
        const chatWindow = document.getElementById('aiChatWindow');
        const messageDiv = document.createElement('div');
        messageDiv.className = `ai-message ${type}`;

        if (style === 'code') {
            messageDiv.innerHTML = `<pre><code>${this.escapeHtml(message)}</code></pre>`;
        } else if (style === 'error') {
            messageDiv.innerHTML = `<span style="color: #ff5555;">\u274C ${this.escapeHtml(message)}</span>`;
        } else {
            messageDiv.textContent = message;
        }

        chatWindow.appendChild(messageDiv);
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the assistant
const tokyoAssistant = new TokyoAssistant();