const { GoogleGenerativeAI } = require('@google/generative-ai');
const fs = require('fs-extra');
const path = require('path');

// Initialize Gemini
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

class AIAssistant {
    constructor() {
        this.model = genAI.getGenerativeModel({ model: "gemini-pro" });
    }

    async handleCommand(command, userId, serverName, filePath) {
        try {
            // Context for the AI
            const context = [
                {
                    role: "user",
                    parts: [
                        `You are Tokyo, an AI assistant helping with Discord bot management.\nUser ID: ${userId}\nServer Name: ${serverName}\nFile Path: ${filePath}\n\nCommand: ${command}`
                    ]
                }
            ];

            const chat = this.model.startChat({
                history: context,
                generationConfig: {
                    maxOutputTokens: 2048,
                }
            });

            const result = await chat.sendMessage(command);
            const response = await result.response;

            // Parse AI response and execute commands
            return await this.executeAICommand(response.text(), userId, serverName, filePath);
        } catch (error) {
            console.error('AI Assistant Error:', error);
            return {
                success: false,
                message: 'حدث خطأ في معالجة الطلب',
                error: error.message
            };
        }
    }

    async executeAICommand(aiResponse, userId, serverName, filePath) {
        // Base path for the server
        const serverPath = path.join(__dirname, '..', 'uploads', userId, serverName);

        // Command parsing logic
        if (aiResponse.includes('VIEW_FILE')) {
            const targetPath = path.join(serverPath, filePath);
            const content = await fs.readFile(targetPath, 'utf8');
            return {
                success: true,
                action: 'view',
                content: content
            };
        }

        if (aiResponse.includes('EDIT_FILE')) {
            const targetPath = path.join(serverPath, filePath);
            const newContent = aiResponse.split('EDIT_FILE:')[1].trim();
            await fs.writeFile(targetPath, newContent);
            return {
                success: true,
                action: 'edit',
                message: 'تم تحديث الملف بنجاح'
            };
        }

        if (aiResponse.includes('CREATE_FILE')) {
            const [_, newPath, content] = aiResponse.match(/CREATE_FILE:(.+?):CONTENT:(.+)/s);
            const targetPath = path.join(serverPath, newPath.trim());
            await fs.ensureFile(targetPath);
            await fs.writeFile(targetPath, content.trim());
            return {
                success: true,
                action: 'create',
                message: 'تم إنشاء الملف بنجاح'
            };
        }

        if (aiResponse.includes('DELETE_FILE')) {
            const targetPath = path.join(serverPath, filePath);
            await fs.remove(targetPath);
            return {
                success: true,
                action: 'delete',
                message: 'تم حذف الملف بنجاح'
            };
        }

        if (aiResponse.includes('CREATE_FOLDER')) {
            const folderPath = aiResponse.split('CREATE_FOLDER:')[1].trim();
            const targetPath = path.join(serverPath, folderPath);
            await fs.ensureDir(targetPath);
            return {
                success: true,
                action: 'create_folder',
                message: 'تم إنشاء المجلد بنجاح'
            };
        }

        return {
            success: true,
            message: aiResponse
        };
    }
}

module.exports = new AIAssistant();